function successfullyLogout(){
    alert('You have been successfully logged out')
}